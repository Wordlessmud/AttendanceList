using System.Security;
using AttendanceList.Models;
using AttendanceList.Services;
using Windows.Data.Xml.Dom;
using Windows.UI.Notifications;

namespace AttendanceList.Platforms.Windows;

public sealed class WindowsLocalNotificationScheduler : ILocalNotificationScheduler
{
    private const string Group = "AttendList";

    public Task<bool> EnsurePermissionAsync(bool requestPermission) => Task.FromResult(true);

    public Task ReplaceAsync(IReadOnlyList<ReminderOccurrence> occurrences)
    {
        var notifier = ToastNotificationManager.CreateToastNotifier();
        foreach (var existing in notifier.GetScheduledToastNotifications().Where(t => t.Group == Group).ToList())
        {
            notifier.RemoveFromSchedule(existing);
        }
        foreach (var occurrence in occurrences)
        {
            var xml = new XmlDocument();
            xml.LoadXml(
                "<toast><visual><binding template=\"ToastGeneric\">" +
                $"<text>{SecurityElement.Escape(occurrence.Title)}</text>" +
                $"<text>{SecurityElement.Escape(occurrence.Message)}</text>" +
                "</binding></visual></toast>");
            var toast = new ScheduledToastNotification(xml, occurrence.When)
            {
                Group = Group,
                Tag = ShortTag(occurrence.Id)
            };
            notifier.AddToSchedule(toast);
        }
        return Task.CompletedTask;
    }

    private static string ShortTag(string value)
    {
        var hash = System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(value));
        return Convert.ToHexString(hash)[..16];
    }
}
